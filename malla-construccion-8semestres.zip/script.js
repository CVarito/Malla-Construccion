
const malla = [
  {
    semestre: 1,
    ramos: [
      { nombre: "Herramientas Digitales", tipo: "especialidad" },
      { nombre: "Interpretación de Planos", tipo: "especialidad" },
      { nombre: "Habilidades Básicas de Comunicación", tipo: "basica" },
      { nombre: "Nivelación Matemática", tipo: "basica" },
      { nombre: "Inglés Básico I", tipo: "complementaria" },
      { nombre: "Curso de Formación Cristiana", tipo: "valores" }
    ]
  },
  {
    semestre: 2,
    ramos: [
      { nombre: "Dibujo y Lectura de Planos", tipo: "especialidad" },
      { nombre: "Partidas de Obra Gruesa", tipo: "especialidad" },
      { nombre: "Álgebra", tipo: "basica" },
      { nombre: "Habilidades de Comunicación Efectiva", tipo: "basica" },
      { nombre: "Inglés Elemental I", tipo: "complementaria" }
    ]
  },
  {
    semestre: 3,
    ramos: [
      { nombre: "Obras Civiles", tipo: "especialidad" },
      { nombre: "Taller de Hormigón", tipo: "especialidad" },
      { nombre: "Contabilidad en la Construcción", tipo: "especialidad" },
      { nombre: "Inglés Elemental II", tipo: "complementaria" },
      { nombre: "Cálculo Diferencial", tipo: "basica" }
    ]
  },
  {
    semestre: 4,
    ramos: [
      { nombre: "Estructuras I", tipo: "especialidad" },
      { nombre: "Instalaciones Domiciliarias", tipo: "especialidad" },
      { nombre: "Obras de Infraestructura", tipo: "especialidad" },
      { nombre: "Gestión de Personas", tipo: "complementaria" },
      { nombre: "Inglés Intermedio I", tipo: "complementaria" }
    ]
  },
  {
    semestre: 5,
    ramos: [
      { nombre: "Obras Viales", tipo: "especialidad" },
      { nombre: "Legislación y Seguridad", tipo: "especialidad" },
      { nombre: "Taller de Instalaciones Domiciliarias", tipo: "especialidad" },
      { nombre: "Tecnología del Hormigón", tipo: "especialidad" },
      { nombre: "Mecánica de Suelos", tipo: "especialidad" }
    ]
  },
  {
    semestre: 6,
    ramos: [
      { nombre: "Taller de Mecánica de Suelos", tipo: "especialidad" },
      { nombre: "Administración y Logística de Obras", tipo: "especialidad" },
      { nombre: "Análisis Estructural", tipo: "especialidad" },
      { nombre: "Taller de Estructuras", tipo: "especialidad" },
      { nombre: "Inglés Intermedio II", tipo: "complementaria" }
    ]
  },
  {
    semestre: 7,
    ramos: [
      { nombre: "Cubicación Presupuesto y Análisis de Costos", tipo: "especialidad" },
      { nombre: "Planificación y Control de Partidas", tipo: "especialidad" },
      { nombre: "Programación de Obras", tipo: "especialidad" },
      { nombre: "Economía y Evaluación de Proyectos", tipo: "especialidad" },
      { nombre: "Ética Profesional", tipo: "valores" }
    ]
  },
  {
    semestre: 8,
    ramos: [
      { nombre: "Portafolio de Título", tipo: "especialidad" },
      { nombre: "Modelamiento y Coordinación de Proyectos", tipo: "especialidad" },
      { nombre: "Taller de Terminaciones", tipo: "especialidad" },
      { nombre: "Construcción Sustentable", tipo: "complementaria" },
      { nombre: "Mentalidad Emprendedora", tipo: "complementaria" }
    ]
  }
];

const container = document.getElementById("malla");

malla.forEach((sem) => {
  const col = document.createElement("div");
  col.className = "semestre";

  const title = document.createElement("h3");
  title.innerText = `${sem.semestre}º Semestre`;
  col.appendChild(title);

  sem.ramos.forEach((ramo) => {
    const div = document.createElement("div");
    div.className = `ramo ${ramo.tipo}`;
    div.innerText = ramo.nombre;

    const key = `ramo-${ramo.nombre}`;
    if (localStorage.getItem(key) === "aprobado") {
      div.classList.add("aprobado");
    }

    div.onclick = () => {
      div.classList.toggle("aprobado");
      localStorage.setItem(key, div.classList.contains("aprobado") ? "aprobado" : "");
    };

    col.appendChild(div);
  });

  container.appendChild(col);
});
