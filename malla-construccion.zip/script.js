const malla = [
  {
    semestre: 1,
    ramos: [
      { nombre: "Herramientas Digitales", tipo: "especialidad" },
      { nombre: "Interpretación de Planos", tipo: "especialidad" },
      { nombre: "Habilidades Básicas de Comunicación", tipo: "basica" },
      { nombre: "Nivelación Matemática", tipo: "basica" },
      { nombre: "Inglés Básico I", tipo: "complementaria" },
      { nombre: "Curso de Formación Cristiana", tipo: "valores" }
    ]
  },
  {
    semestre: 2,
    ramos: [
      { nombre: "Dibujo y Lectura de Planos", tipo: "especialidad" },
      { nombre: "Partidas de Obra Gruesa", tipo: "especialidad" },
      { nombre: "Álgebra", tipo: "basica" },
      { nombre: "Habilidades de Comunicación Efectiva", tipo: "basica" },
      { nombre: "Inglés Elemental I", tipo: "complementaria" }
    ]
  }
];

const container = document.getElementById("malla");

malla.forEach((sem) => {
  const col = document.createElement("div");
  col.className = "semestre";

  const title = document.createElement("h3");
  title.innerText = `${sem.semestre}º Semestre`;
  col.appendChild(title);

  sem.ramos.forEach((ramo) => {
    const div = document.createElement("div");
    div.className = `ramo ${ramo.tipo}`;
    div.innerText = ramo.nombre;

    const key = `ramo-${ramo.nombre}`;
    if (localStorage.getItem(key) === "aprobado") {
      div.classList.add("aprobado");
    }

    div.onclick = () => {
      div.classList.toggle("aprobado");
      localStorage.setItem(key, div.classList.contains("aprobado") ? "aprobado" : "");
    };

    col.appendChild(div);
  });

  container.appendChild(col);
});
